#include <iostream>
#include <vector>
#include <string>

using namespace std;

// Define a structure to represent a task
struct Task {
    string description;  // Task description
    bool isCompleted;    // Task completion status
};

// Function to display the menu
void displayMenu() {
    cout << "\nTo-Do List Application" << endl;
    cout << "1. Add a new task" << endl;
    cout << "2. Mark a task as completed" << endl;
    cout << "3. View all tasks" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
}

// Function to add a new task
void addTask(vector<Task>& tasks) {
    Task newTask;
    cout << "Enter the task description: ";
    cin.ignore(); // To ignore any leftover newline character
    getline(cin, newTask.description); // Get the task description from user
    newTask.isCompleted = false; // Set the task as incomplete
    tasks.push_back(newTask); // Add the new task to the list
    cout << "Task added successfully!" << endl;
}

// Function to mark a task as completed
void markTaskCompleted(vector<Task>& tasks) {
    int taskNumber;
    cout << "Enter the task number to mark as completed: ";
    cin >> taskNumber;

    // Check if the task number is valid
    if (taskNumber > 0 && taskNumber <= tasks.size()) {
        tasks[taskNumber - 1].isCompleted = true; // Mark the task as completed
        cout << "Task marked as completed!" << endl;
    } else {
        cout << "Invalid task number!" << endl;
    }
}

// Function to view all tasks
void viewTasks(const vector<Task>& tasks) {
    cout << "\nCurrent Tasks:" << endl;
    for (size_t i = 0; i < tasks.size(); ++i) {
        cout << i + 1 << ". " << tasks[i].description;
        if (tasks[i].isCompleted) {
            cout << " [Completed]";
        }
        cout << endl;
    }
}

// Main function
int main() {
    vector<Task> tasks; // Vector to store tasks
    int choice;

    while (true) {
        displayMenu(); // Display menu options
        cin >> choice;

        switch (choice) {
            case 1:
                addTask(tasks); // Call function to add a new task
                break;
            case 2:
                markTaskCompleted(tasks); // Call function to mark task as completed
                break;
            case 3:
                viewTasks(tasks); // Call function to view all tasks
                break;
            case 4:
                cout << "Exiting the program. Goodbye!" << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}